#! /bin/sh
echo "${role}:${signal}" >&3
